#include <stdio.h>
#include <stdlib.h>

//Choices Are:
//A  B  C   D   E   F
//20 30 80 CTE RTE NoT

void doChange(int **ptr) {
	int b = 30;
	ptr = &b;
	b = b + 50;
}

int main() {
	int a = 20;
	int *ptr = &a;
	doChange(&ptr);
	printf("\n Output: %d", *ptr);
}
