#include <stdio.h>
#include <stdlib.h>

int sum(int a, int b) {
	return a + b;
}

int sub(int a, int b) {
	return a - b;
}

int calculator(int a, int b, int (*operate)(int, int)) {
	return operate(a, b);
}

int main() {
	int a = 20, b = 30;
	int result = 0;

	result = calculator(a, b, sum);
	printf("\n Result: %d", result);

	result = calculator(a, b, sub);
	printf("\n Result: %d", result);

	//int (*fptr) (int, int) = sum; 
	//printf("\n Output: %d", fptr(a, b));
}
