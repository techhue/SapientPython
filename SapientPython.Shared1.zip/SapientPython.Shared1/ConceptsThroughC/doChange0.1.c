#include <stdio.h>
/*
A.20 20
B.20 80
C.80 80
D.80 20
E. CTE
F. RTE
G. NoT
*/
void doChange(int *ptr) {
	int b = 30;
	b = b + 50;
//	*ptr = b;
	ptr = &b;
}

int main() {
	int a = 20;
	int *ptr = &a;

	doChange(ptr);

	printf("\n Output: %d", a);
	printf("\n Output: %d", *ptr);
}
