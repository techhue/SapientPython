#include <stdio.h>
//Choices Are:
//A  B  C   D   E   F
//20 30 80 CTE RTE NoT
//      7           1
int * doChange(int *ptr) {
	int b = 30;
	ptr = &b;
	b = b + 50;
	return ptr;
}

int main() {
	int a = 20;
	int *ptr = &a;
	ptr = doChange(ptr);
	printf("\n Output: %d", 
			*ptr);
}
