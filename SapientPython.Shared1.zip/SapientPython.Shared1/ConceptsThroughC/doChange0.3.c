#include <stdio.h>
//Choices Are:
//A  B  C   D   E   F
//20 30 80 CTE RTE NoT
//
 
void doChange(int *ptr) {
	int b = 30;
	*ptr = b + 50;
}

int main() {
	int a = 20;
	//int *ptr = &a;
	doChange(&a);
	printf("\n Output: %d", 
			a);
}
