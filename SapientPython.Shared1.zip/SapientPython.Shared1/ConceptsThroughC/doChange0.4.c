#include <stdio.h>
//Choices Are:
//A  B  C   D   E   F
//20 30 80 CTE RTE NoT
//
 
void doChange(int a) {
	int b = 30;
	a = b + 50;
}

int main() {
	int a = 20;
	doChange(a);
	printf("\n Output: %d", 
			a);
}
