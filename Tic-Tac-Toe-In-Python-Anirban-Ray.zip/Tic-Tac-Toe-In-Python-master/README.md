# Tic Tac Toe in Python

- Implementation in Python 3
- Possible options:
  - Variable board size (any natural number greater than or equal to 3)
  - Two player mode
  - Player vs Machine mode [machine is dumb]
  - Undo the last move
  - Replay with same configuration
  - Quit the game before finishing and save it to play letter
